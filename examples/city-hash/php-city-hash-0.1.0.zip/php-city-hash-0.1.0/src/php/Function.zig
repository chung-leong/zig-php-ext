const std = @import("std");
const builtin = @import("builtin");

pub const Arguments = @import("Function/Arguments.zig");
pub const CallCache = @import("Function/CallCache.zig");
pub const Closure = @import("Function/Closure.zig");
const php = @import("root.zig");
const php_al = php.allocator;
const Array = php.Array;
const c = php.c;
const pi = php.imports;
const Callable = php.Callable;
const Class = php.Class;
const Dictionary = php.Dictionary;
const failure = php.failure;
const Object = php.Object;
const Resource = php.Resource;
const Singleton = php.Singleton;
const String = php.String;
const Value = php.Value;

pub fn name(self: *const @This()) *String {
    const zstr = self.impl.common.function_name orelse return .create("");
    return @ptrCast(zstr);
}

pub fn create(comptime func: anytype, comptime options: Options) *@This() {
    const self = php_al.create(@This());
    self.* = .init(func, options);
}

pub fn register(self: *@This()) !void {
    const cg = php.globals("compiler");
    const list: *Array = @ptrCast(cg.function_table);
    const lc_name = self.name().createLowerCase();
    defer lc_name.release();
    if (list.has(lc_name)) return error.NameConflict;
    list.set(lc_name, .fromPointer(&self));
}

pub fn unregister(self: *@This()) !void {
    const cg = php.globals("compiler");
    const list: *Array = @ptrCast(cg.function_table);
    const lc_name = self.name().createLowerCase();
    defer lc_name.release();
    list.delete(lc_name);
}

pub fn createClosure(self: *const @This(), scope: ?*Class, called_scope: ?*Class, this: ?Value) Closure {
    return .create(self, scope, called_scope, this);
}

pub fn init(comptime func: anytype, comptime options: Options) @This() {
    const handler_info = comptime handlerInfo(func, options.self_source);
    const arg_info = argInfo(handler_info);
    var flags = c.ZEND_ACC_PUBLIC;
    if (options.is_static) flags |= c.ZEND_ACC_NEVER_CACHE | c.ZEND_ACC_STATIC;
    if (handler_info.is_variadic) flags |= c.ZEND_ACC_VARIADIC;
    const func_name = String.static(extractName(func));
    return .{
        .impl = .{
            .internal_function = .{
                .type = c.ZEND_INTERNAL_FUNCTION,
                .function_name = @ptrCast(func_name),
                .handler = @ptrCast(&internalFunction(func, options.self_source)),
                .num_args = handler_info.arguments.len,
                .required_num_args = handler_info.required_count,
                .arg_info = @constCast(arg_info.ptr),
                .fn_flags = flags,
            },
        },
    };
}

pub fn handlerType(comptime F: type, comptime self_src: SelfSource) HandlerType {
    const info = @typeInfo(F);
    if (info != .@"fn") @compileError("Function expected, received: " ++ @typeName(F));
    const AT = info.@"fn".param_types;
    const RT = info.@"fn".return_type.?;
    const PT = switch (@typeInfo(RT)) {
        .error_union => |eu| eu.payload,
        else => RT,
    };
    if (AT.len == 2 and AT[0] == *Arguments and AT[1] == *Value and PT == void) return .raw;
    if (AT.len == 1 and @typeInfo(AT[0].?) == .@"struct") return .handler;
    if (AT.len == 2 and self_src.match(AT[0].?)) {
        if (@typeInfo(AT[1].?) == .@"struct") return .method;
        @compileError("Improper method handler: " ++ @typeName(F));
    }
    @compileError("Improper function handler: " ++ @typeName(F));
}

pub fn isExtraArg(comptime arg_name: []const u8) ?enum { named, unnamed } {
    return if (std.mem.eql(u8, arg_name, "..."))
        .unnamed
    else if (std.mem.eql(u8, arg_name, "???"))
        .named
    else
        null;
}

pub fn handlerInfo(comptime func: anytype, comptime self_src: SelfSource) HandlerInfo {
    const F = @TypeOf(func);
    const handler_type = handlerType(F, self_src);
    const arg_names, const arg_types, const arg_attrs, const is_raw = switch (handler_type) {
        .raw => .{ &.{}, &.{}, &.{}, true },
        .handler, .method => init: {
            const f = @typeInfo(F).@"fn";
            const AT = f.param_types;
            const offset = if (handler_type == .method) 1 else 0;
            const Struct = AT[offset].?;
            const st = @typeInfo(Struct).@"struct";
            break :init .{ st.field_names, st.field_types, st.field_attrs, false };
        },
    };
    const arg_count, const has_extra = init: {
        var count: usize = 0;
        var extra = false;
        inline for (arg_names) |arg_name| {
            if (comptime isExtraArg(arg_name)) |_| {
                extra = true;
            } else {
                count += 1;
            }
        }
        break :init .{ count, extra };
    };
    const is_variadic = is_raw or has_extra or switch (arg_types.len) {
        0 => false,
        else => acceptsNamedParameters(arg_types[arg_types.len - 1]),
    };
    const arguments, const required_count = init: {
        var arguments: [arg_count]ArgumentInfo = undefined;
        var required_count: usize = 0;
        inline for (0..arg_count) |i| {
            const arg_name = arg_names[i];
            const required = switch (arg_attrs[i].default_value_ptr != null) {
                true => false,
                false => switch (@typeInfo(arg_types[i])) {
                    .optional => false,
                    else => true,
                },
            };
            const by_ref = switch (arg_types[i]) {
                *Value, ?*Value => true,
                else => false,
            };
            if (required) required_count += 1;
            arguments[i] = .{
                .name = arg_name,
                .required = required,
                .by_ref = by_ref,
            };
        }
        break :init .{ &arguments, required_count };
    };
    return .{
        .type = handler_type,
        .arguments = arguments,
        .required_count = required_count,
        .is_variadic = is_variadic,
    };
}

fn acceptsNamedParameters(comptime AT: type) bool {
    return switch (@typeInfo(AT)) {
        .optional => |op| acceptsNamedParameters(op.child),
        .error_union => |eu| acceptsNamedParameters(eu.payload),
        .@"union" => AT == Dictionary,
        .@"struct" => true,
        else => false,
    };
}

pub fn internalFunction(comptime func: anytype, comptime self_src: SelfSource) Handler {
    const F = @TypeOf(func);
    const handler_type = handlerType(F, self_src);
    const f = @typeInfo(F).@"fn";
    const AT = f.param_types;
    const returning_error = @typeInfo(f.return_type.?) == .error_union;
    const cc: std.lang.CallingConvention = @typeInfo(Handler).@"fn".attrs.@"callconv";
    const ns = struct {
        pub fn handler(zed: [*c]c.zend_execute_data, zretval: [*c]c.zval) callconv(cc) void {
            const args: *Arguments = @ptrCast(zed);
            const retval: *Value = @ptrCast(zretval);
            var iter = args.iterate();
            if (iter.extract(AT[0].?)) |arg0| {
                defer Value.freeConverted(arg0);
                const result = switch (returning_error) {
                    true => func(arg0) catch |err| return failure.throw(err),
                    false => func(arg0),
                };
                retval.* = .fromAny(result);
            } else |err| failure.throw(err);
        }

        pub fn method(zed: [*c]c.zend_execute_data, zretval: [*c]c.zval) callconv(cc) void {
            const php_args: *Arguments = @ptrCast(zed);
            const retval: *Value = @ptrCast(zretval);
            var iter = php_args.iterate();
            // the self variable is either a singleton or held in PHP's $this variable
            const arg0 = switch (self_src) {
                .singleton => |T| Singleton(T).get(),
                .this_object => |T| get: {
                    const obj = iter.this.getObject() catch |err| return failure.throw(err);
                    break :get switch (T) {
                        Object => obj, // self is a standard object
                        else => obj.custom(T), // self is a custom object
                    };
                },
                .this_pointer => |T| get: {
                    // self is some data structure that we reference by a pointer
                    const ptr = iter.this.getPointer() catch |err| return failure.throw(err);
                    break :get @as(*T, @ptrCast(@alignCast(ptr)));
                },
                .none => unreachable,
            };
            if (iter.extract(AT[1].?)) |arg1| {
                defer Value.freeConverted(arg1);
                const result = switch (returning_error) {
                    true => func(arg0, arg1) catch |err| return failure.throw(err),
                    false => func(arg0, arg1),
                };
                retval.* = .fromAny(result);
            } else |err| failure.throw(err);
        }

        pub fn raw(zed: [*c]c.zend_execute_data, zretval: [*c]c.zval) callconv(cc) void {
            const args: *Arguments = @ptrCast(zed);
            const retval: *Value = @ptrCast(zretval);
            switch (returning_error) {
                true => func(args, retval) catch |err| return failure.throw(err),
                false => func(args, retval),
            }
        }
    };
    return @field(ns, @tagName(handler_type));
}

pub fn extractName(comptime func: anytype) []const u8 {
    const ns = struct {
        pub fn Dummy(comptime arg: anytype) type {
            return struct {
                comptime x: @TypeOf(arg) = arg,
            };
        }
    };
    const type_name = @typeName(ns.Dummy(func));
    const si = std.mem.indexOfScalar(u8, type_name, '\'').?;
    const ei = std.mem.lastIndexOfScalar(u8, type_name, '\'').?;
    return type_name[si + 1 .. ei];
}

pub const Handler = switch (builtin.target.os.tag) {
    .windows => init: {
        // handler uses fastcall
        const f = @typeInfo(StdHandler).@"fn";
        var param_types: [f.param_types.len]type = undefined;
        for (f.param_types, 0..) |param_type, i| param_types[i] = param_type.?;
        break :init @Fn(&param_types, f.param_attrs, f.return_type.?, .{
            .@"callconv" = switch (builtin.target.cpu.arch) {
                .x86_64 => .{ .x86_64_vectorcall = .{} },
                .x86 => .{ .x86_vectorcall = .{} },
                else => .c,
            },
        });
    },
    else => StdHandler,
};
pub const HandlerInfo = struct {
    type: HandlerType,
    arguments: []ArgumentInfo,
    required_count: usize,
    is_variadic: bool,
};
pub const ArgumentInfo = struct {
    name: [:0]const u8,
    required: bool,
    by_ref: bool,
};
pub const HandlerType = enum { handler, raw, method };
pub const SelfSource = union(enum) {
    this_object: type,
    this_pointer: type,
    singleton: type,
    none: void,

    pub fn match(self: @This(), Arg0: type) bool {
        return switch (self) {
            inline .this_object, .this_pointer, .singleton => |T| match: {
                if (@typeInfo(T) == .pointer) @compileError("Unexpected pointer");
                switch (@typeInfo(Arg0)) {
                    .pointer => |pt| break :match pt.child == T,
                    else => {
                        if (Arg0 == T) @compileError("self should be a pointer");
                        break :match false;
                    },
                }
            },
            .none => false,
        };
    }
};
pub const Options = struct {
    self_source: SelfSource,
    is_static: bool = false,
};

const ArgInfoEntry = @typeInfo(@FieldType(c.zend_internal_function, "arg_info")).pointer.child;

fn argInfo(comptime info: HandlerInfo) []const ArgInfoEntry {
    const len = info.arguments.len + if (info.is_variadic) 1 else 0;
    const array = init: {
        var buffer: [len]ArgInfoEntry = undefined;
        for (info.arguments, 0..) |arg, i| {
            buffer[i] = .{
                .name = switch (@FieldType(ArgInfoEntry, "name")) {
                    [*c]c.zend_string => @ptrCast(String.static(arg.name)), // 8.6
                    else => arg.name,
                },
                .type = .{
                    .type_mask = if (arg.by_ref) 1 << c._ZEND_SEND_MODE_SHIFT else 0,
                },
            };
        }
        break :init buffer;
    };
    return &array;
}

const StdHandler = fn ([*c]c.zend_execute_data, [*c]c.zval) callconv(.c) void;
const Function = @This();

impl: c.zend_function,
