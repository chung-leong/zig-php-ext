const std = @import("std");

const php = @import("root.zig");
const Array = php.Array;
const Dictionary = php.Dictionary;
const Class = php.Class;
const failure = php.failure;
const unsupported = failure.unsupported;
const List = php.List;
const Object = php.Object;
const php_al = php.allocator;
const Reference = php.Reference;
const Resource = php.Resource;
const Stream = php.Stream;
const String = php.String;
const Value = php.Value;
pub const api = @import("util/api.zig");
pub const macgyver = @import("util/macgyver.zig");
pub const symbol = @import("util/symbol.zig");

pub fn fieldCount(comptime T: anytype) usize {
    return std.meta.fieldNames(T).len;
}

pub fn functionCount(comptime T: anytype) usize {
    return comptime count: {
        var count: usize = 0;
        for (std.meta.declarations(T)) |decl_name| {
            if (@typeInfo(@TypeOf(@field(T, decl_name))) == .@"fn") count += 1;
        }
        break :count count;
    };
}

pub fn argCount(comptime F: type) usize {
    return switch (@typeInfo(F)) {
        .pointer => |pt| argCount(pt.child),
        .@"fn" => @typeInfo(F).@"fn".param_types.len,
        else => @compileError("Not a function or function pointer: " ++ @typeName(F)),
    };
}

pub fn ArgType(comptime F: type, comptime index: usize) type {
    return switch (@typeInfo(F)) {
        .pointer => |pt| ArgType(pt.child, index),
        .@"fn" => get: {
            const types = @typeInfo(F).@"fn".param_types;
            if (index >= types.len) @compileError("Index exceeds the argument count: " ++ @typeName(F));
            break :get types[index] orelse @compileError("Unexpected generic function: " ++ @typeName(F));
        },
        else => @compileError("Not a function or function pointer: " ++ @typeName(F)),
    };
}

pub fn ReturnType(comptime F: type) type {
    return switch (@typeInfo(F)) {
        .pointer => |pt| ReturnType(pt.child),
        .@"fn" => @typeInfo(F).@"fn".return_type orelse @compileError("Cannot determine return value type"),
        else => @compileError("Not a function or function pointer"),
    };
}

pub fn WithoutError(comptime T: type) type {
    return switch (@typeInfo(T)) {
        .error_union => |eu| eu.payload,
        else => T,
    };
}

pub fn isScalarType(comptime T: type) bool {
    return switch (@typeInfo(T)) {
        .bool, .comptime_int, .int, .comptime_float, .float => true,
        .enum_literal => true,
        .pointer => |pt| switch (pt.size) {
            .one => switch (@typeInfo(pt.child)) {
                .array => |ar| ar.child == u8,
                else => false,
            },
            .slice => pt.child == u8,
            else => false,
        },
        else => false,
    };
}

pub fn canBeConstant(comptime T: type) bool {
    return comptime switch (@typeInfo(T)) {
        .@"enum" => true,
        .array => |ar| isScalarType(ar.child),
        .@"struct" => |st| for (st.field_types) |FT| {
            if (!isScalarType(FT)) break false;
        } else true,
        .pointer => |pt| switch (pt.size) {
            .slice => isScalarType(pt.child),
            else => false,
        },
        else => false,
    };
}

pub fn errable(arg: anytype) !WithoutError(@TypeOf(arg)) {
    return switch (@typeInfo(@TypeOf(arg))) {
        .error_union => try arg,
        else => arg,
    };
}

pub fn hasRequiredFields(comptime T: type) bool {
    const st = @typeInfo(T).@"struct";
    return inline for (st.field_attrs) |attrs| {
        if (attrs.default_value_ptr == null) break true;
    } else false;
}

pub fn hasPointer(comptime T: anytype) bool {
    return switch (@typeInfo(T)) {
        .error_union => |eu| hasPointer(eu.payload),
        .pointer => true,
        .optional => |op| hasPointer(op.child),
        .array => |ar| hasPointer(ar.child),
        inline .@"struct", .@"union" => |st| inline for (st.field_types) |FT| {
            if (hasPointer(FT)) break true;
        } else false,
        else => false,
    };
}

pub fn hasU8Slice(comptime T: anytype) bool {
    return switch (@typeInfo(T)) {
        .error_union => |eu| hasU8Slice(eu.payload),
        .pointer => |pt| switch (pt.size) {
            .slice => switch (pt.child) {
                u8 => true,
                else => hasU8Slice(pt.child),
            },
            else => false,
        },
        .optional => |op| hasU8Slice(op.child),
        inline .@"struct", .@"union" => |st| inline for (st.field_types) |FT| {
            if (hasU8Slice(FT)) break true;
        } else false,
        else => false,
    };
}

pub fn hasCustomObject(comptime T: anytype) bool {
    return switch (@typeInfo(T)) {
        .error_union => |eu| hasCustomObject(eu.payload),
        .pointer => |pt| switch (pt.size) {
            .one => switch (@typeInfo(pt.child)) {
                .@"struct" => true,
                else => false,
            },
            else => false,
        },
        .optional => |op| hasCustomObject(op.child),
        inline .@"struct", .@"union" => |st| inline for (st.field_types) |FT| {
            if (hasCustomObject(FT)) break true;
        } else false,
        else => false,
    };
}

pub fn getFieldDefaultValue(comptime T: type, comptime field_name: []const u8) ?@FieldType(T, field_name) {
    const st = @typeInfo(T).@"struct";
    const field_attr, const FT: type = comptime for (st.field_names, st.field_attrs, st.field_types) |name, attrs, FT| {
        if (std.mem.eql(u8, field_name, name)) {
            break .{ attrs, FT };
        }
    } else @compileError("Struct has no field by that name: " ++ field_name);
    const opaque_ptr = field_attr.default_value_ptr orelse return null;
    const def_value_ptr: *const FT = @ptrCast(@alignCast(opaque_ptr));
    return def_value_ptr.*;
}

pub fn fieldHasDefaultValue(arg: anytype, comptime field_name: []const u8) bool {
    const T = @TypeOf(arg);
    return switch (@typeInfo(T)) {
        .@"struct" => check: {
            const def_value = getFieldDefaultValue(T, field_name) orelse return false;
            const value = @field(arg, field_name);
            break :check std.meta.eql(value, def_value);
        },
        .pointer => return fieldHasDefaultValue(arg.*, field_name),
        else => false,
    };
}

pub fn retainAny(arg: anytype, options: struct {
    duplicate_slice: bool = true,
}) @TypeOf(arg) {
    const T = @TypeOf(arg);
    if (comptime !php.util.hasPointer(T)) return arg;
    return switch (@typeInfo(T)) {
        .error_union => if (arg) |payload| retainAny(payload, options) else |err| err,
        .pointer => |pt| switch (pt.size) {
            .one => switch (pt.child) {
                Array, Object, Reference, Resource, Stream, String => arg.retain(),
                else => if (@typeInfo(pt.child) == .@"struct") retain: {
                    Object.fromCustom(arg).addRef();
                    break :retain arg;
                } else {
                    unsupported(T);
                },
            },
            .slice => retain: {
                if (options.duplicate_slice) {
                    if (comptime php.util.hasPointer(T)) {
                        const sentinel, const extra: usize = if (comptime pt.sentinel()) |sentinel|
                            .{ sentinel, 1 }
                        else
                            .{ undefined, 0 };
                        const new_slice = php_al.alloc(pt.child, arg.len + extra) catch unreachable;
                        for (arg, 0..) |element, i| {
                            new_slice[i] = retainAny(element, options);
                        }
                        break :retain if (extra == 1) new_slice[0..arg.len :sentinel] else new_slice;
                    } else {
                        break :retain if (pt.sentinel()) |sentinel|
                            php_al.dupeSentinel(pt.child, arg, sentinel)
                        else
                            php_al.dupe(pt.child, arg);
                    }
                } else {
                    for (arg) |element| _ = retainAny(element, options);
                    break :retain arg;
                }
            },
            else => unsupported(T),
        },
        .optional => if (arg) |payload| retainAny(payload, options) else null,
        .array => retain: {
            var new_array: T = undefined;
            for (arg, 0..) |value, i| {
                new_array[i] = retainAny(value, options);
            }
            break :retain new_array;
        },
        .@"struct" => |st| switch (T) {
            Value => arg.retain(),
            else => if (st.backing_integer == null) retain: {
                var new_struct: T = undefined;
                inline for (st.field_names) |field_name| {
                    @field(new_struct, field_name) = retainAny(@field(arg, field_name), options);
                }
                break :retain new_struct;
            } else arg,
        },
        .@"union" => |un| switch (T) {
            Dictionary, List => arg.retain(),
            else => if (un.tag_type) |_| switch (arg) {
                inline else => |payload, tag| @unionInit(T, @tagName(tag), retainAny(payload, options)),
            },
        },
        else => unreachable,
    };
}

pub fn freeAny(arg: anytype) void {
    const T = @TypeOf(arg);
    if (comptime !hasPointer(T)) return;
    switch (@typeInfo(T)) {
        .error_union => if (arg) |payload| freeAny(payload) else |_| {},
        .pointer => |pt| switch (pt.size) {
            .one => switch (pt.child) {
                Array, Object, Object.StdClass, Reference, Resource, Stream, String => arg.release(),
                else => if (@typeInfo(pt.child) == .@"struct") {
                    Object.fromCustom(arg).release();
                },
            },
            .slice => {
                if (comptime hasPointer(pt.child)) {
                    for (arg) |element| freeAny(element);
                }
                php_al.free(arg);
            },
            else => unsupported(T),
        },
        .optional => if (arg) |payload| freeAny(payload),
        .array => for (arg) |value| freeAny(value),
        .@"struct" => |st| switch (T) {
            Value => arg.release(),
            else => if (st.backing_integer == null) {
                inline for (st.field_names, st.field_attrs) |field_name, field_attrs| {
                    // attempt to free value only if it's does not match the field's default value
                    if (!field_attrs.@"comptime" and !fieldHasDefaultValue(arg, field_name)) {
                        const value = @field(arg, field_name);
                        freeAny(value);
                    }
                }
            },
        },
        .@"union" => |un| switch (T) {
            Dictionary, List => arg.release(),
            else => if (un.tag_type) |_| {
                switch (arg) {
                    inline else => |payload| freeAny(payload),
                }
            } else unsupported(T),
        },
        else => {},
    }
}

pub fn autoConvertible(T: type) bool {
    return switch (@typeInfo(T)) {
        .void, .null, .bool, .comptime_float, .comptime_int, .float, .@"enum" => true,
        .int => true,
        .error_union => |eu| autoConvertible(eu.payload),
        .array, .vector => |ar| autoConvertible(ar.child),
        .optional => |op| autoConvertible(op.child),
        .pointer => |pt| switch (pt.size) {
            .one => switch (pt.child) {
                Array, Object, Object.StdClass, Reference, Resource, Stream, String => true,
                else => switch (@typeInfo(pt.child)) {
                    .array => |ar| ar.child == u8,
                    .@"struct" => true,
                    else => false,
                },
            },
            .slice => switch (pt.child) {
                u8 => true,
                else => autoConvertible(pt.child),
            },
            else => false,
        },
        .@"struct" => true,
        .@"union" => |un| inline for (un.field_types) |FT| {
            if (!autoConvertible(FT)) break false;
        } else true,
        else => false,
    };
}

pub fn autoFreeable(comptime T: type) bool {
    return switch (@typeInfo(T)) {
        .error_union => |eu| autoFreeable(eu.payload),
        .pointer => |pt| switch (pt.size) {
            .one => switch (pt.child) {
                Array, Object, Object.StdClass, Reference, Resource, Stream, String => true,
                else => autoFreeable(pt.child),
            },
            .slice => autoFreeable(pt.child),
            else => false,
        },
        .optional => |op| autoFreeable(op.child),
        .@"struct" => |st| switch (T) {
            Value => true,
            else => st.backing_integer != null or comptime for (st.field_types) |FT| {
                if (!autoFreeable(FT)) break false;
            } else true,
        },
        .@"union" => |un| switch (T) {
            Dictionary, List => true,
            else => un.tag_type != null and comptime for (un.field_types) |FT| {
                if (!autoFreeable(FT)) break false;
            } else true,
        },
        else => true,
    };
}

pub fn getArgumentType(allocator: std.mem.Allocator, comptime Argument: type) []const u8 {
    var helper: struct {
        pub fn init(a: std.mem.Allocator) @This() {
            return .{ .arena = .init(a), .allocator = a };
        }

        pub fn deinit(self: *@This()) void {
            self.arena.deinit();
        }

        pub fn getName(self: *@This()) ![]const u8 {
            const items = try self.getAcceptable(Argument);
            return switch (items.len) {
                0 => unreachable,
                1 => try self.allocator.dupe(u8, items[0]),
                2 => try std.mem.join(self.allocator, " or ", items),
                else => try std.mem.join(self.allocator, ", or ", &.{
                    try std.mem.join(self.arena.allocator(), ", ", items[0 .. items.len - 1]),
                    items[items.len - 1],
                }),
            };
        }

        pub fn getAcceptable(self: *@This(), comptime T: type) ![]const []const u8 {
            return switch (@typeInfo(T)) {
                .bool => &.{"boolean"},
                .int => &.{"integer"},
                .float => &.{"floating pointer number"},
                .array, .vector => &.{"array"},
                .pointer => |pt| switch (pt.size) {
                    .one => switch (pt.child) {
                        String => &.{"string"},
                        Array => &.{"array"},
                        Object => &.{"object"},
                        Resource => &.{"resource"},
                        Value => &.{"reference"},
                        else => get: {
                            const list = try self.arena.allocator().alloc([]const u8, 1);
                            list[0] = Class.Custom(pt.child).get().name().slice();
                            break :get list;
                        },
                    },
                    .slice => switch (pt.child) {
                        u8 => &.{ "string", "array" },
                        else => &.{"array"},
                    },
                    else => unsupported(T),
                },
                .optional => |opt| try self.getAcceptable(opt.child),
                .error_union => |eu| try self.getAcceptable(eu.payload),
                .@"struct" => |st| switch (T) {
                    php.Callable => &.{"callable"},
                    else => if (st.backing_integer != null)
                        &.{ "number", "associative array", "object" }
                    else
                        &.{"associative array"},
                },
                .@"union" => |un| switch (T) {
                    Dictionary => &.{ "associative array", "object" },
                    else => get: {
                        var list: std.ArrayList([]const u8) = .empty;
                        inline for (un.field_types) |FT| {
                            for (try self.getAcceptable(FT)) |name| {
                                const included = for (list.items) |item| {
                                    if (std.mem.eql(u8, item, name)) break true;
                                } else false;
                                if (!included) try list.append(self.arena.allocator(), name);
                            }
                        }
                        break :get list.items;
                    },
                },
                .@"enum" => &.{ "number", "string" },
                else => unsupported(T),
            };
        }

        arena: std.heap.ArenaAllocator,
        allocator: std.mem.Allocator,
    } = .init(allocator);
    defer helper.deinit();
    return helper.getName() catch unreachable;
}

pub fn getFieldList(comptime T: type, comptime conjunction: []const u8) [:0]const u8 {
    return comptime join: {
        const field_names = std.meta.fieldNames(T);
        const last = field_names.len - 1;
        var combined: []const u8 = "";
        for (field_names, 0..) |field_name, i| {
            const quoted = "'" ++ field_name ++ "'";
            const sep_prefix = if (last != 1) ", " else " ";
            const sep = if (i == last)
                sep_prefix ++ conjunction ++ " "
            else
                sep_prefix;
            combined = if (i == 0) quoted else combined ++ sep ++ quoted;
        }
        break :join combined[0.. :0];
    };
}

pub fn extractFunctionName(comptime func: anytype) []const u8 {
    // stupid hack making use of the fact that the function names show up in the
    // names of parametric types
    const ns = struct {
        pub fn Dummy(comptime arg: anytype) type {
            return struct {
                comptime x: @TypeOf(arg) = arg,
            };
        }
    };
    const type_name = @typeName(ns.Dummy(func));
    const si = std.mem.indexOfScalar(u8, type_name, '\'').?;
    const ei = std.mem.lastIndexOfScalar(u8, type_name, '\'').?;
    return type_name[si + 1 .. ei];
}

pub inline fn camelize(comptime name: []const u8) [:0]const u8 {
    var buffer: [name.len + 1]u8 = undefined;
    var len: usize = 0;
    var capitalize = false;
    for (name) |c| {
        if (c == '_') {
            capitalize = true;
        } else if (capitalize) {
            buffer[len] = std.ascii.toUpper(c);
            len += 1;
            capitalize = false;
        } else {
            buffer[len] = c;
            len += 1;
        }
    }
    buffer[len] = 0;
    return @ptrCast(buffer[0..len]);
}

pub fn decamelize(comptime name: []const u8) []const u8 {
    const array = init: {
        var buffer: [name.len * 2]u8 = undefined;
        const result = decamelizeInto(name, &buffer);
        var array: [result.len]u8 = undefined;
        @memcpy(&array, result);
        break :init array;
    };
    return @ptrCast(&array);
}

pub fn decamelizeAlloc(allocator: std.mem.Allocator, name: []const u8) ![:0]const u8 {
    const buffer = try allocator.alloc(u8, name.len * 2);
    return decamelizeInto(name, buffer);
}

fn decamelizeInto(name: []const u8, buffer: []u8) [:0]const u8 {
    var len: usize = 0;
    for (name, 0..) |char, i| {
        const conversion_needed = check: {
            var needed = false;
            if (std.ascii.isUpper(char)) {
                // previous letter is not uppercase
                if (i == 0 or !std.ascii.isUpper(name[i - 1])) {
                    // next letter is not uppercase
                    if (i == name.len - 1 or !std.ascii.isUpper(name[i + 1])) {
                        needed = true;
                    }
                }
            }
            break :check needed;
        };
        if (conversion_needed) {
            if (i > 0) {
                buffer[len] = ' ';
                len += 1;
            }
            buffer[len] = std.ascii.toLower(char);
            len += 1;
        } else {
            buffer[len] = char;
            len += 1;
        }
        buffer[len] = 0;
    }
    return @ptrCast(buffer[0..len]);
}
